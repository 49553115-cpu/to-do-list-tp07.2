using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using PrimerProyecto.Models;

namespace PrimerProyecto.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly ILogger<UsuarioController> _logger;

        public UsuarioController(ILogger<UsuarioController> logger)
        {
            _logger = logger;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string usuario, string contraseña)
        {
            Usuario u = BD.GetUsuarioPorUsername(usuario);

            if (u != null && u.contraseña == contraseña)
            {
                HttpContext.Session.SetString("usuario", u.usuario);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.Error = "Usuario o contraseña incorrectos";
                return View();
            }
        }

        public IActionResult Registrar()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Registrar(string usuario, string email, string contraseña)
        {
            Usuario existente = BD.GetUsuarioPorUsername(usuario);

            if (existente == null)
            {
                Usuario nuevo = new Usuario(usuario, email, contraseña);
                BD.InsertarUsuario(nuevo);

                HttpContext.Session.SetString("usuario", nuevo.usuario);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.Error = "El nombre de usuario ya existe";
                return View();
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
