using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using PrimerProyecto.Models;

namespace PrimerProyecto.Controllers;

public class Tarea : Controller
{
    private readonly ILogger<Tarea> _logger;

    public Tarea(ILogger<Tarea> logger)
    {
        _logger = logger;
    }
}