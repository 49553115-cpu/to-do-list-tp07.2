public class Tarea
{
    public int id { get; set; }
    public int numero { get; set; }
    public DateTime fechaFinal { get; set; }
    public DateTime fechaInicio { get; set; }
    public string descripcion { get; set; }
    public bool activa { get; set; }
    public string categoria { get; set; }
    
     public Tarea(int id, int numero, DateTime fechaFinal, DateTime fechaInicio, string descripcion, bool activa, string categoria)
    {
        this.id = id;
        this.numero = numero;
        this.fechaFinal = fechaFinal;
        this.fechaInicio = fechaInicio;
        this.descripcion = descripcion;
        this.activa = activa;
        this.categoria = categoria;
    }
}