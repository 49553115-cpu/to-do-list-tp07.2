using Microsoft.Data.SqlClient;
using Dapper;

namespace PrimerProyecto.Models
{
    public static class BD
    {
        private static string _connectionString = "Server=localhost;Database=TuBase;Trusted_Connection=True;TrustServerCertificate=True;";

        public static Usuario GetUsuarioPorUsername(string usuario)
        {
            using (SqlConnection bd = new SqlConnection(_connectionString))
            {
                string sql = "SELECT * FROM Usuarios WHERE usuario = @pUsuario";
                return bd.QueryFirstOrDefault<Usuario>(sql, new { pUsuario = usuario });
            }
        }

        public static void InsertarUsuario(Usuario u)
        {
            using (SqlConnection bd = new SqlConnection(_connectionString))
            {
                string sql = "INSERT INTO Usuarios (usuario, email, contraseña) VALUES (@pUsuario, @pEmail, @pContraseña)";
                bd.Execute(sql, new { pUsuario = u.usuario, pEmail = u.email, pContraseña = u.contraseña });
            }
        }
    }
}
