namespace PrimerProyecto.Models
{
    public class Usuario
    {
        public int id { get; set; }
        public string usuario { get; set; }
        public string email { get; set; }
        public string contraseña { get; set; }

        public Usuario() { }

        public Usuario(string usuario, string email, string contraseña)
        {
            this.usuario = usuario;
            this.email = email;
            this.contraseña = contraseña;
        }
    }
}
