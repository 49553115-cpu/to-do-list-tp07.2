public class tareaXusuario{
    public int idUsuario{get;set;}
    public int idTarea{get;set;}
    public bool creador {get;set;}
}